Connection STring: Server=localhost;Database=Quiz;Uid=student;Pwd=secret;

I have added the quiz database file. you will need to import the database into a sql server.

I used a student user with secret as the password. goodluck!
